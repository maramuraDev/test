# AR.js - Augmented Reality in 10 lines of html

A Pen created on CodePen.io. Original URL: [https://codepen.io/jeromeetienne/pen/mRqqzb](https://codepen.io/jeromeetienne/pen/mRqqzb).

Augmented Reality on the Web in 10 lines of html - AR.js with a-frame magic 

https://github.com/jeromeetienne/ar.js